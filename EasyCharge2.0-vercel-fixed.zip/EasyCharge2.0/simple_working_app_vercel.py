from flask import Flask, render_template_string
import json
import random

app = Flask(__name__)

# HTML template for the web app
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>EasySearch - EV Charging Sites</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <style>
        body { margin:0; padding:0; font-family: Arial, sans-serif; background-color: #f4f7f6; color: #333; }
        #header { background-color: #2c3e50; color: white; padding: 15px 20px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.2); }
        #header h1 { margin: 0; font-size: 28px; }
        #header p { margin: 5px 0 0; font-size: 16px; opacity: 0.9; }
        #map { height: 600px; width: 90%; margin: 20px auto; border-radius: 8px; box-shadow: 0 0 15px rgba(0,0,0,0.1); }
        #stats { display: flex; justify-content: center; flex-wrap: wrap; gap: 20px; padding: 20px; background-color: #ecf0f1; border-radius: 8px; width: 90%; margin: 20px auto; box-shadow: 0 0 10px rgba(0,0,0,0.05); }
        .stat-card { background-color: white; padding: 20px 30px; border-radius: 8px; text-align: center; min-width: 180px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); transition: transform 0.2s ease; }
        .stat-card:hover { transform: translateY(-5px); }
        .stat-number { font-size: 32px; font-weight: bold; color: #2980b9; margin-bottom: 5px; }
        .stat-label { font-size: 14px; color: #7f8c8d; }
        #site-list-container { width: 90%; margin: 20px auto; background-color: #ffffff; border-radius: 8px; box-shadow: 0 0 15px rgba(0,0,0,0.1); padding: 20px; }
        #site-list-container h3 { color: #2c3e50; border-bottom: 2px solid #ecf0f1; padding-bottom: 10px; margin-top: 0; }
        .site-item { padding: 15px; border-bottom: 1px solid #eee; display: flex; align-items: center; gap: 15px; }
        .site-item:last-child { border-bottom: none; }
        .site-id { background-color: #3498db; color: white; border-radius: 50%; width: 35px; height: 35px; display: flex; justify-content: center; align-items: center; font-weight: bold; font-size: 14px; flex-shrink: 0; }
        .site-details { flex-grow: 1; }
        .site-details strong { color: #2c3e50; }
        .site-details a { color: #3498db; text-decoration: none; }
        .site-details a:hover { text-decoration: underline; }
        .no-sites { text-align: center; padding: 50px; color: #7f8c8d; font-size: 18px; }
    </style>
</head>
<body>
    <div id="header">
        <h1>EasySearch EV Charging Sites</h1>
        <p>Optimizing EV infrastructure placement in Catalonia</p>
    </div>

    {% if sites %}
    <div id="stats">
        <div class="stat-card">
            <div class="stat-number">{{ total_sites }}</div>
            <div class="stat-label">Candidate Sites</div>
        </div>
        <div class="stat-card">
            <div class="stat-number">{{ "{:,.0f}".format(total_chargers) }}</div>
            <div class="stat-label">Potential Chargers</div>
        </div>
        <div class="stat-card">
            <div class="stat-number">€{{ "{:,.0f}".format(total_investment) }}</div>
            <div class="stat-label">Investment Opportunity</div>
        </div>
        <div class="stat-card">
            <div class="stat-number">€{{ "{:,.0f}".format(total_revenue) }}</div>
            <div class="stat-label">Annual Revenue</div>
        </div>
    </div>

    <div id="map"></div>

    <div id="site-list-container">
        <h3>📍 Site Details</h3>
        <p>These sites are located near major highways in Catalonia with high traffic intensity (>10,000 vehicles/day).</p>
        
        <div id="sites">
            {% for site in sites %}
            <div class="site-item">
                <div class="site-id">{{ site.id }}</div>
                <div class="site-details">
                    <strong>Location:</strong> {{ site.lat:.6f}}, {{ site.lon:.6f}}<br>
                    <strong>Land Use:</strong> {{ site.land_use }}<br>
                    <strong>Area:</strong> {{ "{:,.0f}".format(site.area) }} m²<br>
                    <strong>Score:</strong> {{ site.score:.3f }}<br>
                    <strong>Potential Chargers:</strong> {{ "{:,.0f}".format(site.chargers) }}<br>
                    <a href="https://maps.google.com/?q={{ site.lat }},{{ site.lon }}" target="_blank">View on Google Maps</a>
                </div>
            </div>
            {% endfor %}
        </div>
    </div>

    <script>
        var map = L.map('map').setView([{{ center_lat }}, {{ center_lon }}], 9);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        var sites = {{ sites | tojson }};

        sites.forEach(function(site) {
            L.marker([site.lat, site.lon]).addTo(map)
                .bindPopup(
                    "<b>Site ID:</b> " + site.id + "<br>" +
                    "<b>Land Use:</b> " + site.land_use + "<br>" +
                    "<b>Area:</b> " + site.area.toLocaleString() + " m²<br>" +
                    "<b>Score:</b> " + site.score.toFixed(3) + "<br>" +
                    "<b>Potential Chargers:</b> " + site.chargers.toLocaleString() + "<br>" +
                    "<a href='https://maps.google.com/?q=" + site.lat + "," + site.lon + "' target='_blank'>View on Google Maps</a>"
                );
        });
    </script>
    {% else %}
    <div class="no-sites">
        <p>❌ No candidate sites found. Please run the EasySearch analysis first!</p>
    </div>
    {% endif %}
</body>
</html>
"""

def generate_mock_sites():
    """Generate mock EV charging sites for demonstration."""
    sites = []
    
    # Catalonia coordinates (Barcelona area)
    base_lat, base_lon = 41.3851, 2.1734
    
    for i in range(10):
        # Generate sites around Barcelona with some variation
        lat = base_lat + random.uniform(-0.3, 0.3)
        lon = base_lon + random.uniform(-0.3, 0.3)
        
        site = {
            'id': i + 1,
            'lat': lat,
            'lon': lon,
            'land_use': random.choice(['Industrial', 'Commercial', 'Mixed Use', 'Transport']),
            'area': random.randint(2000, 8000),
            'score': round(random.uniform(0.6, 0.95), 3),
            'chargers': random.randint(8, 25)
        }
        sites.append(site)
    
    return sites

@app.route('/')
def index():
    sites = generate_mock_sites()
    
    # Calculate statistics
    total_sites = len(sites)
    total_area = sum(site['area'] for site in sites)
    total_chargers = sum(site['chargers'] for site in sites)
    total_investment = total_chargers * 50000  # €50k per charger
    total_revenue = total_chargers * 15000     # €15k annual revenue per charger
    
    # Calculate map center
    if sites:
        center_lat = sum(s['lat'] for s in sites) / len(sites)
        center_lon = sum(s['lon'] for s in sites) / len(sites)
    else:
        center_lat, center_lon = 41.3851, 2.1734  # Default to Barcelona

    return render_template_string(HTML_TEMPLATE, 
                                  sites=sites, 
                                  total_sites=total_sites,
                                  total_chargers=total_chargers,
                                  total_investment=total_investment,
                                  total_revenue=total_revenue,
                                  center_lat=center_lat,
                                  center_lon=center_lon)

if __name__ == '__main__':
    print("🌐 Starting EasySearch EV Charging Sites App...")
    print("📍 Open your browser to: http://localhost:5000")
    print("🗺️  View your EV charging sites on an interactive map!")
    print("🔋 Found sites in Catalonia, Spain")
    app.run(debug=True, host='0.0.0.0', port=5000)
