# EasySearch EV Charging Sites

A web application for finding optimal EV charging station locations in Catalonia, Spain.

## Features

- Interactive map showing candidate EV charging sites
- Real-time analysis of highway proximity and traffic data
- Business intelligence dashboard
- Optimized for high-traffic areas (>10,000 vehicles/day)

## Quick Start

1. The app is ready to deploy on Vercel
2. Just upload this repository to GitHub
3. Connect to Vercel for automatic deployment

## Files

- `simple_working_app.py` - Main Flask application
- `requirements.txt` - Python dependencies
- `vercel.json` - Vercel deployment configuration

## Live Demo

Once deployed, you'll have a live web app showing EV charging sites across Catalonia with:
- Interactive map with site locations
- Site details and scoring
- Business metrics and investment opportunities

Built for EasyCharge (VINCI-affiliated initiative) to identify and broker land for EV charging infrastructure across Spain.
