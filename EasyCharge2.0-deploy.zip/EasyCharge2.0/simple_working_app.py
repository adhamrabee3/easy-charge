#!/usr/bin/env python3
"""
Simple Working EasySearch App - Shows EV charging sites
"""

from flask import Flask, render_template_string, jsonify
import geopandas as gpd
import pandas as pd
from pathlib import Path
import sys

app = Flask(__name__)

def load_results():
    """Load the latest EasySearch results."""
    results_path = Path("outputs/top_candidates.geojson")
    if results_path.exists():
        data = gpd.read_file(results_path)
        # Convert to WGS84 for web display
        if data.crs != 'EPSG:4326':
            data = data.to_crs('EPSG:4326')
        print(f"✅ Loaded {len(data)} candidate sites")
        return data
    else:
        print("❌ No results found!")
        return None

@app.route('/')
def index():
    """Main page."""
    data = load_results()
    
    if data is None or len(data) == 0:
        return """
        <!DOCTYPE html>
        <html>
        <head><title>EasySearch - No Sites</title></head>
        <body style="font-family: Arial; text-align: center; padding: 50px;">
            <h1>🔋 EasySearch</h1>
            <h2 style="color: red;">No candidate sites found!</h2>
            <p>Please run the EasySearch analysis first.</p>
        </body>
        </html>
        """
    
    # Calculate stats safely
    total_sites = len(data)
    total_area = 0
    for area in data.get('parcel_area_m2', []):
        try:
            total_area += float(area) if area is not None else 0
        except:
            total_area += 0
    
    total_chargers = int(total_area / 200)
    total_investment = total_chargers * 50000
    total_revenue = total_chargers * 15000
    
    # Prepare sites data safely
    sites = []
    for idx, row in data.iterrows():
        try:
            if hasattr(row.geometry, 'centroid'):
                centroid = row.geometry.centroid
                lat, lon = centroid.y, centroid.x
            else:
                lat, lon = 41.3851, 2.1734
            
            # Safe area conversion
            area = row.get('parcel_area_m2', 0)
            try:
                area = float(area) if area is not None else 0
            except:
                area = 0
            
            # Safe score conversion
            score = row.get('score_final', 0)
            try:
                score = float(score) if score is not None else 0
            except:
                score = 0
            
            site = {
                'id': idx + 1,
                'lat': lat,
                'lon': lon,
                'land_use': 'Commercial/Industrial',
                'area': int(area),
                'score': score,
                'chargers': int(area / 200)
            }
            sites.append(site)
        except Exception as e:
            print(f"Error processing site {idx}: {e}")
            continue
    
    return render_template_string("""
    <!DOCTYPE html>
    <html>
    <head>
        <title>EasySearch - EV Charging Sites</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
        <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
        <style>
            body { 
                font-family: Arial, sans-serif; 
                margin: 0; 
                padding: 0; 
                background: #f5f5f5;
            }
            .header {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 20px;
                text-align: center;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            .header h1 {
                margin: 0;
                font-size: 2.5em;
                font-weight: 300;
            }
            .header p {
                margin: 10px 0 0 0;
                opacity: 0.9;
                font-size: 1.1em;
            }
            .stats {
                display: flex;
                justify-content: center;
                gap: 20px;
                padding: 20px;
                flex-wrap: wrap;
            }
            .stat-card {
                background: white;
                padding: 20px;
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                text-align: center;
                min-width: 150px;
            }
            .stat-number {
                font-size: 2em;
                font-weight: bold;
                color: #667eea;
                margin-bottom: 5px;
            }
            .stat-label {
                color: #666;
                font-size: 0.9em;
            }
            #map {
                height: 500px;
                margin: 20px;
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            .site-list {
                margin: 20px;
                background: white;
                padding: 20px;
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            .site-item {
                border: 1px solid #eee;
                border-radius: 8px;
                padding: 15px;
                margin: 10px 0;
                display: flex;
                align-items: center;
                gap: 15px;
            }
            .site-id {
                background: #667eea;
                color: white;
                width: 40px;
                height: 40px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                font-weight: bold;
                flex-shrink: 0;
            }
            .site-details {
                flex: 1;
            }
            .site-details a {
                color: #667eea;
                text-decoration: none;
                font-weight: bold;
            }
            .site-details a:hover {
                text-decoration: underline;
            }
        </style>
    </head>
    <body>
        <div class="header">
            <h1>🔋 EasySearch</h1>
            <p>EV Charging Sites in Catalonia, Spain</p>
        </div>

        <div class="stats">
            <div class="stat-card">
                <div class="stat-number">{{ total_sites }}</div>
                <div class="stat-label">Candidate Sites</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">{{ total_chargers }}</div>
                <div class="stat-label">Potential Chargers</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">€{{ total_investment }}</div>
                <div class="stat-label">Investment Opportunity</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">€{{ total_revenue }}</div>
                <div class="stat-label">Annual Revenue</div>
            </div>
        </div>

        <div id="map"></div>

        <div class="site-list">
            <h3>📍 Site Details</h3>
            <p>These sites are located near major highways in Catalonia with high traffic intensity (>10,000 vehicles/day).</p>
            
            <div id="sites">
                {% for site in sites %}
                <div class="site-item">
                    <div class="site-id">{{ site.id }}</div>
                    <div class="site-details">
                        <strong>Location:</strong> {{ "%.6f"|format(site.lat) }}, {{ "%.6f"|format(site.lon) }}<br>
                        <strong>Land Use:</strong> {{ site.land_use }}<br>
                        <strong>Area:</strong> {{ site.area }} m²<br>
                        <strong>Score:</strong> {{ "%.3f"|format(site.score) }}<br>
                        <strong>Potential Chargers:</strong> {{ site.chargers }}<br>
                        <a href="https://maps.google.com/?q={{ site.lat }},{{ site.lon }}" target="_blank">View on Google Maps</a>
                    </div>
                </div>
                {% endfor %}
            </div>
        </div>

        <script>
            // Initialize map
            var map = L.map('map').setView([41.3851, 2.1734], 9);
            
            // Add tile layer
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors'
            }).addTo(map);
            
            // Add markers for each site
            var sites = {{ sites | tojson }};
            var markers = [];
            
            sites.forEach(function(site) {
                var marker = L.marker([site.lat, site.lon]).addTo(map);
                marker.bindPopup(`
                    <b>Site ${site.id}</b><br>
                    Land Use: ${site.land_use}<br>
                    Area: ${site.area} m²<br>
                    Score: ${site.score.toFixed(3)}<br>
                    Potential Chargers: ${site.chargers}<br>
                    <a href="https://maps.google.com/?q=${site.lat},${site.lon}" target="_blank">View on Google Maps</a>
                `);
                markers.push(marker);
            });
            
            // Fit map to show all markers
            if (markers.length > 0) {
                var group = new L.featureGroup(markers);
                map.fitBounds(group.getBounds().pad(0.1));
            }
        </script>
    </body>
    </html>
    """, 
    total_sites=total_sites,
    total_chargers=total_chargers,
    total_investment=total_investment,
    total_revenue=total_revenue,
    sites=sites)

if __name__ == '__main__':
    port = 5004
    if len(sys.argv) > 1 and '--port' in sys.argv:
        port_idx = sys.argv.index('--port')
        if port_idx + 1 < len(sys.argv):
            port = int(sys.argv[port_idx + 1])
    
    print("🌐 Starting Simple Working EasySearch App...")
    print(f"📍 Open your browser to: http://localhost:{port}")
    print("🗺️  View your EV charging sites on an interactive map!")
    print("🔋 Found sites in Catalonia, Spain")
    
    app.run(debug=True, host='0.0.0.0', port=port)
